export function TestPage() {
  return (
    <div className="w-full h-screen bg-[#0a0e27] flex items-center justify-center">
      <h1 className="text-white text-4xl">Test Page Works!</h1>
    </div>
  );
}
