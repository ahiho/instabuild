// Simple chat hook without AI SDK for MVP
export function useChat(pageId: string) {
  // This will be implemented when AI SDK is properly configured
  console.log('Chat hook for page:', pageId);
  return null;
}
